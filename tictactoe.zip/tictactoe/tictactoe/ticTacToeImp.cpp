
//Tic-Tac-Toe Implementation file

#include <iostream>
#include <iomanip>
#include <string>

#include "ticTacToe.h"

using namespace std;

string player1 = " ";
string player2 = " ";
string currentPlayer = " ";
int p1Wins = 0;
int p2Wins = 0;
int player1Wins = 0;
int player2Wins = 0;
int player2Losses = 0;
int player1Losses = 0;
int player1Draws = 0;
int player2Draws = 0;

void ticTacToe::play()
{
	bool done = false;
	char player = ' ';
	char playerChoice = ' ';
	int player1Losses = 0;
	int player2Losses = 0;
	
	//Getting player name
	cout << "Player 1 please enter your name (No Spaces): ";
	cin >> player1;
	cout << endl;

	cout << "Player 2 please enter your name (No Spaces): ";
	cin >> player2;
	cout << endl;
	//Player chooses what they want to start as, x is default if they enter
	//an improper character.
	cout << player1 << " would you like to be x's or o's?" << endl;
	cout << "(Enter x or o) If you do not enter x or o, then"
		<< " you will start as x." << endl;
	cin >> playerChoice;
	cout << endl;

	currentPlayer = player1;

	if (playerChoice == 'x' || playerChoice == 'X')
	{
		player = 'X';
		cout << player1 << " is now x's. That means "
			<< player2 << " is o's." << endl;
	}
	else if (playerChoice == 'o' || playerChoice == 'O')
	{
		player = 'O';
		cout << player1 << " is now o's. That means "
			<< player2 << " is x's." << endl;
	}

	else
	{
		player = 'X';
		cout << player1 << " did not input a proper answer. "
			<< player1 << " is now x's and " << player2
			<< " is o's." << endl;
	}



	displayBoard();


	while (!done)
	{
		done = getXOMove(player, currentPlayer);

		if (player == 'X')
			player = 'O';
		else
			player = 'X';

		//Alternates player names every time a turn ends.
		if (currentPlayer == player1)
			currentPlayer = player2;
		else
			currentPlayer = player1;

	}

	//resets the game
	reStart();

	
}

void ticTacToe::displayBoard() const
{
	cout << "   1   2   3" << endl << endl;

	for (int row = 0; row < 3; row++)
	{
		cout << row + 1;

		for (int col = 0; col < 3; col++)
		{
			cout << setw(3) << board[row][col];

			if (col != 2)
				cout << "|";
		}

		cout << endl;

		if (row != 2)
			cout << " ___|___|___" << endl
			<< "    |   |   " << endl;
	}

	cout << endl;
}

bool ticTacToe::isValidMove(int row, int col) const
{
	if (0 <= row && row <= 2 && 0 <= col && col <= 2
		&& board[row][col] == ' ')
		return true;
	else
		return false;
}

bool ticTacToe::getXOMove(char playerSymbol, string name)
{
	int row, col;

	do
	{
		cout << name << " enter your move: ";
		cin >> row >> col;
		cout << endl;
	} while (!isValidMove(row - 1, col - 1));

	row--;
	col--;

	noOfMoves++;

	board[row][col] = playerSymbol;
	displayBoard();

	//check each play for a winner
	status gStatus;

	gStatus = gameStatus();

	if (gStatus == WIN)
	{
		cout << name << " wins!" << endl;
		if (name == player1)
		{
			//If player 1 wins, then player 1 gets one win to their
			//stats and player 2 gets one loss to their stats.
			player1Wins += 1;
			player2Losses += 1;

			cout << player1 << " has " << player1Wins << " wins!" << endl;
		}
		if (name == player2)
		{
			//If player 2 wins, then player 2 gets one win to their
			//stats and player 1 gets one loss to their stats.
			player2Wins += 1;
			player1Losses += 1;

			cout << player2 << " has " << player2Wins << " wins!" << endl;
		}
		return true;
	}
	else if (gStatus == DRAW)
	{
		cout << "This game is a draw!" << endl;

		//If there is a draw, then both players get one draw
		//added to their stats.
		player1Draws += 1;
		player2Draws += 1;

		return true;
	}
	else
		return false;
}

status ticTacToe::gameStatus()
{
	//Check rows for a win
	for (int row = 0; row < 3; row++)
		if (board[row][0] != ' ' && (board[row][0] == board[row][1]) &&
			(board[row][1] == board[row][2]))
			return WIN;

	//Check columns for a win
	for (int col = 0; col < 3; col++)
		if (board[0][col] != ' ' && (board[0][col] == board[1][col]) &&
			(board[1][col] == board[2][col]))
			return WIN;

	//check diagonals for a win
	if (board[0][0] != ' ' && (board[0][0] == board[1][1]) &&
		(board[1][1] == board[2][2]))
		return WIN;

	if (board[2][0] != ' ' && (board[2][0] == board[1][1]) &&
		(board[1][1] == board[0][2]))
		return WIN;

	if (noOfMoves < 9)
		return CONTINUE;

	return DRAW;
}

void ticTacToe::reStart()
{
	for (int row = 0; row < 3; row++)
		for (int col = 0; col < 3; col++)
			board[row][col] = ' ';

	noOfMoves = 0;
}

void ticTacToe::playerStats()
{
	cout << player1 << " Stats: " << endl;
	cout << "\tWins: " << player1Wins << endl;
	cout << "\tDraws: " << player1Draws << endl;
	cout << "\tLosses: " << player1Losses << endl
		<< endl;
	
	cout << player2 << " Stats: " << endl;
	cout << "\tWins: " << player2Wins << endl;
	cout << "\tDraws: " << player2Draws << endl;
	cout << "\tLosses: " << player2Losses << endl
		<< endl;

}

ticTacToe::ticTacToe()
{
	for (int row = 0; row < 3; row++)
		for (int col = 0; col < 3; col++)
			board[row][col] = ' ';

	noOfMoves = 0;
}

