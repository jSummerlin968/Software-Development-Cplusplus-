/*
	Name:			Joseph Summerlin
	Date:			11.7.2018
	Description:	Lets the user play a game of tic tac toe.
*/

//Main program

#include <iostream>

#include "ticTacToe.h"

using namespace std;

int main()
{
	int hold = 0;
	char answer = 'y';
	ticTacToe game;

	do
	{


		game.play();

		cout << "Would you like to play again? (y/Y, n/N)" << endl;
		cin >> answer;
		cout << endl;

	} while (answer == 'y' || answer == 'Y');
	game.playerStats(); //display player stats when players are done playing

	cin >> hold;
	return 0;
}