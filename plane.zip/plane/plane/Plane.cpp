/*
Name: Joseph Summerlin
Date: 10.9.2018
Description: User can buy seats for the Dassault Mercure 100 plane. Includes seat plan for the plan via arrays and for loops.
*/

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <string>

using namespace std;

//constant variables
const double FIRSTCLASS = 579.99;
const double BUSINESS = 389.99;
const double ECONOMY = 259.99;
const double TAX = 0.075;
const int NUMSEAT = 5;
const int ROWS = 3;
const int ROWSECO = 23;

//prototypes
void sInitializeFirstClass(char array[3][5]);
void sInitializeBusiness(char array[23][5]);
void sInitializeEco(char array[23][5]);
void printFirstClass(char array[3][5]);
void printBusiness(char array[23][5]);
void printEco(char array[23][5]);

int main()
{
	
	//variables
	double total = 0.00;
	char firstClassRow[ROWS] [NUMSEAT] = {};
	char economyRow[ROWSECO] [NUMSEAT]= {};
	char businessRow[ROWSECO] [NUMSEAT] = {};
	char columnFirst = ' ';
	char columnEco = ' ';
	char columnBus = ' ';
	char answer = 'y';
	int choice1 = 0;
	int hold = 0;
	int rowFirst = 0;
	int rowEco = 0;
	int rowBus = 0;
	int receiptFirst = 0;
	int receiptEco = 0;
	int receiptBus = 0;

	cout << fixed << showpoint << setprecision(2);
	
	sInitializeFirstClass(firstClassRow);//function call
	sInitializeEco(economyRow);//function call
	sInitializeBusiness(businessRow);//function call
	do
	{
		cout << "Hello. Are you interested in buying First Class, "
			<< "Economy, or Business seating." << endl;
		cout << "1. First Class" << endl
			<< "2. Economy    " << endl << "3. Business   " << endl
			<< "4. Exit       " << endl;
		cin >> choice1;

		switch (choice1)
		{
			case(1): //First Class seating
			{
			
				cout << "Here are the current seats that are available on the plane "
					<< "in First Class. " << endl;
			
				printFirstClass(firstClassRow);//function call
				cout << "What row would you like to sit in? (1 - 3)" << endl;
				cin >> rowFirst;
				cout << endl << "What column would you like to sit in?"
					<< " (A, B, C, or D)" << endl;
				cin >> columnFirst;
			
				if (rowFirst == 1) //row 1
				{
					if (columnFirst == 'a' || columnFirst == 'A')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 0)
									{
										cout << "There isn't a seat there. Please pick a different seat." << endl;
										
									}
								}
							
							}

						}
					}
					else if (columnFirst == 'b' || columnFirst == 'B')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 1)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst == 'c' || columnFirst == 'C')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 3)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 4)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowFirst == 2) //row 2
				{
					if (columnFirst == 'a' || columnFirst == 'A')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 0)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst == 'b' || columnFirst == 'B')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 1)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst == 'c' || columnFirst == 'C')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 3)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 4)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}
				else if (rowFirst == 3) //row 3
				{
					if (columnFirst == 'a' || columnFirst == 'A')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 0)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst == 'b' || columnFirst == 'B')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 1)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst == 'c' || columnFirst == 'C')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 3)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 3; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 4)
									{
										if (firstClassRow[i][j] != 'x')
										{
											firstClassRow[i][j] = 'x';
											total += FIRSTCLASS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptFirst += 1;
											printFirstClass(firstClassRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else
					cout << "That was an improper answer." << endl;
					//end of ROWS if else statement
			
				break;
			}//end of case 1

			case(2): // Economy
			{
			
				cout << "Here are the current seats that are available on the plane "
					<< "in Economy seating. " << endl;
				printEco(economyRow);//function call
				cout << "What row would you like to sit in? (1 - 23)" << endl;
				cin >> rowEco;
				cout << endl << "What column would you like to sit in?"
					<< " (A, B, C, or D)" << endl;
				cin >> columnEco;

				if (rowEco == 1) //row 1
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 2) //row 2
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 3) //row 3
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 4) //row 4
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 5) //row 5
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 6) //row 6
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 7) //row 7
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 8) //row 8
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 9) //row 9
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 10) //row 10
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 11) //row 11
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 12) //row 12
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 13) //row 13
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 14) //row 14
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 15) //row 15
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 16) //row 16
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 17) //row 17
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 18) //row 18
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 19) //row 19
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 20) //row 20
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 21) //row 21
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 22) //row 22
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowEco == 23) //row 23
				{
					if (columnEco == 'a' || columnEco == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 0)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'b' || columnEco == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 1)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco == 'c' || columnEco == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 3)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnEco = 'd' || columnEco == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 4)
									{
										if (economyRow[i][j] != 'x')
										{
											economyRow[i][j] = 'x';
											total += ECONOMY;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptEco += 1;
											printEco(economyRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else
				{
					cout << "That was an improper answer." << endl;
				}//end of ROWS if else statement

			 break;
			}//end of case 2

			case(3):
			{

				cout << "Here are the current seats that are available on the plane "
					<< "in Business Seating. " << endl;

				printBusiness(businessRow);//function call
				cout << "What row would you like to sit in? (1 - 23)" << endl;
				cin >> rowBus;
				cout << endl << "What column would you like to sit in?"
					<< " (A, B, C, or D)" << endl;
				cin >> columnBus;

				if (rowBus == 1)
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 0)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 2) //row 2
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 1)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 3) //row 3
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 2)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 4) //row 4
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 3)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 5) //row 5
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 4)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 6) //row 6
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 5)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 7) //row 7
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 6)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 8) //row 8
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 7)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 9) //row 9
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 8)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 10) //row 10
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 9)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 11) //row 11
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 10)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 12) //row 12
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 11)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 13) //row 13
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 12)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 14) //row 14
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 13)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 15) //row 15
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 14)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 16) //row 16
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 15)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 17) //row 17
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 16)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 18) //row 18
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 17)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 19) //row 19
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 18)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 20) //row 20
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 19)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 21) //row 21
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 20)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 22) //row 22
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 21)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else if (rowBus == 23) //row 23
				{
					if (columnBus == 'a' || columnBus == 'A')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 0)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;

									}
								}

							}

						}
					}
					else if (columnBus == 'b' || columnBus == 'B')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 1)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnBus == 'c' || columnBus == 'C')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 3)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow);//function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else if (columnFirst = 'd' || columnFirst == 'D')
					{
						for (int i = 0; i < 23; i++)
						{
							for (int j = 0; j < 5; j++)
							{
								if (i == 22)
								{
									if (j == 4)
									{
										if (businessRow[i][j] != 'x')
										{
											businessRow[i][j] = 'x';
											total += BUSINESS;
											cout << "Your total is now: $" << total << " with a tax of 7.5%" << endl;
											receiptBus += 1;
											printBusiness(businessRow); //function call
											answer = ' ';
											cout << "Would you like to purchase another plane ticket? " << endl;
											cin >> answer;
											cout << endl;
										}

										else
											cout << "That seat is unavailable, please choose again." << endl;
									}
								}

							}

						}
					}
					else
					{
						cout << "That was an improper answer." << endl;
					}// end of column If Else statement
				}

				else
					cout << "That was an improper answer." << endl;
					//end of ROWS if else statement

				break;
			} //end of case 3

			default:
			{
				cout << "User entered an improper answer or exited! " << endl;
				answer = ' ';
				break;
			}// end of default
			

		}//end of switch

	} while (answer == 'y' || answer == 'Y');

	cout << "Receipt: " << endl;
	cout << "\t First Class Seats: " << receiptFirst << endl;
	cout << "\t Business Seats: " << receiptBus << endl;
	cout << "\t Economy Seats: " << receiptEco << endl;
	cout << "Subtotal:  $" << setfill('#') << setw(15) << total << endl;
	cout << "Sales Tax: $" << setfill('#') << setw(15) << total * (TAX) << endl;
	cout << "Total:     $" << setfill('#') << setw(15) << total * (TAX)+total << endl;

	cin >> hold;
	return 0;
}



void sInitializeFirstClass(char array[3][5])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			
			array[i][j] = 'o';

			if (i == 0)
				if (j == 0)
					array[i][j] = ' ';
			
			if (j == 2)
			{
				array[i][j] = ' ';
			}
			
		}
		
	}
}

void sInitializeEco(char array[23][5])
{
	for (int i = 0; i < 23; i++)
	{
		for (int j = 0; j < 5; j++)
		{

			array[i][j] = 'o';

			if (j == 2)
			{
				array[i][j] = ' ';
			}

		}

	}
}

void sInitializeBusiness(char array[23][5])
{
	for (int i = 0; i < 23; i++)
	{
		for (int j = 0; j < 5; j++)
		{

			array[i][j] = 'o';

			if (j == 2)
			{
				array[i][j] = ' ';
			}

		}

	}
}

void printFirstClass(char array[3][5])
{
	cout << setw(11) << "A" << setw(5) << "B" << setw(5) << " " << setw(5) << "C" << setw(5) << "D" << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << left << setw(3) << "Row " << setw(2) << i + 1;
		for (int j = 0; j < 5; j++)
		{
			cout << right << setw(5) << array[i][j];
		}
		cout << endl;
	}
	cout << "o = Available Seat" << endl;
	cout << "x = Unavailable Seat" << endl;
}

void printEco(char array[23][5])
{
	cout << setw(11) << "A" << setw(5) << "B" << setw(5) << " " << setw(5) << "C" << setw(5) << "D" << endl;
	for (int i = 0; i < 23; i++)
	{
		cout << left << setw(3) << "Row " << setw(2) << i + 1;
		for (int j = 0; j < 5; j++)
		{
			cout << right << setw(5) << array[i][j];
		}
		cout << endl;
	}
	cout << "o = Available Seat" << endl;
	cout << "x = Unavailable Seat" << endl;
}

void printBusiness(char array[23][5])
{
	cout << setw(11) << "A" << setw(5) << "B" << setw(5) << " " << setw(5) << "C" << setw(5) << "D" << endl;
	for (int i = 0; i < 23; i++)
	{
		cout << left << setw(3) << "Row " << setw(2) << i + 1;
		for (int j = 0; j < 5; j++)
		{
			cout << right << setw(5) << array[i][j];
		}
		cout << endl;
	}
	cout << "o = Available Seat" << endl;
	cout << "x = Unavailable Seat" << endl;
}