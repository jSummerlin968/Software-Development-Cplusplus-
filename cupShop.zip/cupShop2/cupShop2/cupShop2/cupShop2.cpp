/*
Names: Joseph Summerlin
Date: 9.20.2018
Description: It's a cup shop that sells cups.
*/

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

const double BLACKMUG = 52.00;
const double REDMUG = 64.00;
const double YELLOWMUG = 72.00;
const double BLACKCUP = 43.00;
const double REDCUP = 58.00;
const double YELLOWCUP = 67.00;
const double BLACKBOTTLE = 55.00;
const double REDBOTTLE = 73.99;
const double YELLOWBOTTLE = 98.00;
const double TAX = 0.07;

//function prototypes
int menu();

void showMenu();

int main()
{
	int hold = 0;
	menu();

	cin >> hold;
	return 0;
}

void showMenu() //shows category menu
{

	cout << "Welcome to J's Cup Shop! "
		<< "Please choose from the list and enter number below: " << endl;
	cout << " 1. Temperature-Controlling Mugs      " << endl;
	cout << " 2. Fancy Water Bottles               " << endl;
	cout << " 3. Insulated Cups                    " << endl;
	cout << " 4. Exit                              " << endl;
	
}

int menu()
{
	//variables
	int hold;
	int choice = 0;
	int selection = 0;
	int totalItem = 0;
	int totalRedCup = 0;
	int totalBlackCup = 0;
	int totalYellowCup = 0;
	int totalBlackBottle = 0;
	int totalRedBottle = 0;
	int totalYellowBottle = 0;
	int totalBlackMug = 0;
	int totalRedMug = 0;
	int totalYellowMug = 0;
	int receiptBlackCup = 0;
	int receiptRedCup = 0;
	int receiptYellowCup = 0;
	int receiptBlackBottle = 0;
	int receiptRedBottle = 0;
	int receiptYellowBottle = 0;
	int receiptBlackMug = 0;
	int receiptRedMug = 0;
	int receiptYellowMug = 0;
	double total = 0.00;
	char answer = ' '; //determines if user buys another item
	char answer2 = ' '; //determines if user removes another item from their cart
	char answer3 = ' '; //determines if user has a coupon for a specific item
	char answer4 = ' '; //determines if user has a coupon for 5% off their total price.
	int coupon = 0; //determines whether coupon off of total price can be used.

	cout << "Do you have a coupon for 20% off a specific item? (y / n)" << endl;
	cin >> answer3;

	if (answer3 == 'y' || answer3 == 'Y') //Menu for coupons
	{
		coupon += 1;
		do
		{
			
			showMenu(); //function call
			cin >> choice;

			switch (choice)
			{
			case 1: //Mugs
			{

				char answer = ' '; //Colors
				cout << "You chose Temperature-Controlling Mugs!" << endl;
				cout << "We have three different colors. " << endl;
				cout << "1. Black ($52)" << endl;
				cout << "2. Red ($64)" << endl;
				cout << "3. Yellow ($72)" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalBlackMug;
					total += (totalBlackMug * (BLACKMUG * 0.8));
					receiptBlackMug += totalBlackMug;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalRedMug;
					total += totalRedMug * (REDMUG * 0.8);
					receiptRedMug += totalRedMug;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 3) //Yellow
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalYellowMug;
					total += totalYellowMug * (YELLOWMUG * 0.8);
					receiptYellowMug += totalYellowMug;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;

				}

				else //User enters something other than 1, 2, or 3.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			} //end of case 1
			case 2: //Bottles
			{

				char answer = ' '; //Colors
				cout << "You chose Fancy Water Bottles." << endl;
				cout << "1. Black ($55)" << endl;
				cout << "2. Red ($73.99)" << endl;
				cout << "3. Yellow ($98)" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalBlackBottle;
					total += (totalBlackBottle * (BLACKBOTTLE * 0.8));
					receiptBlackBottle += totalBlackBottle;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalRedBottle;
					total += totalRedBottle * (REDBOTTLE * 0.8);
					receiptRedBottle += totalRedBottle;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 3) //Yellow
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalYellowBottle;
					total += totalYellowBottle * (YELLOWBOTTLE * 0.8);
					receiptYellowBottle += totalYellowBottle;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else //User enters something other than 1, 2, 3, or 4.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			} //end of case 2
			case 3: //Cups
			{

				char answer = ' '; //Colors
				cout << "You chose Insulated Cups!" << endl;
				cout << "We have three different colors." << endl;
				cout << "1. Black ($43)" << endl;
				cout << "2. Red ($58)" << endl;
				cout << "3. Yellow ($67)" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalBlackCup;
					total += totalBlackCup * (BLACKCUP * 0.8);
					receiptBlackCup += totalBlackCup;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalRedCup;
					total += totalRedCup * (REDCUP * 0.8);
					receiptRedCup += totalRedCup;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else if (choice == 3) //Yellow
				{
					cout << "How many would you like to buy: " << endl;
					cin >> totalYellowCup;
					total += totalYellowCup * (YELLOWCUP * 0.8);
					receiptYellowCup += totalYellowCup;
					cout << fixed << showpoint << setprecision(2);
					cout << "Your total is currently: $"
						<< total << " with a tax of 7%." << endl;
				}

				else //User enters something other than 1, 2, or 3.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			} //end of case 3
			default:
			{
				cout << "User exited or entered an improper answer" << endl
					<< endl;
				break;
			}


			} //end of switch
			answer = ' ';
			cout << "Would you like to buy anything else with a coupon? (y or n)" << endl;
			cin >> answer; //If user enters y they can buy more. If user enters any other character it goes to receipt.


		} while (answer == 'y' || answer == 'Y'); //end of do / while
	}

	else if (answer3 == 'n' || answer3 == 'N')
	{
		cout << "We have coupons in newspapers at the front of the store." << endl;
		cout << "Feel free to take one if you want one." << endl;
	}

	else
	{
		cout << "That was an improper answer..." << endl;
	}

	do //Menu without coupons. Will run even if coupon menu was run.
	{
		showMenu(); //function call
		cin >> choice;

		switch (choice)
		{
		case 1: //Mugs
		{

			char answer = ' '; //Colors
			cout << "You chose Temperature-Controlling Mugs!" << endl;
			cout << "We have three different colors. " << endl;
			cout << "1. Black" << endl;
			cout << "2. Red" << endl;
			cout << "3. Yellow" << endl;
			cin >> choice;

			if (choice == 1) //Black
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalBlackMug;
				total += (totalBlackMug * BLACKMUG);
				receiptBlackMug += totalBlackMug;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 2) //Red
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalRedMug;
				total += totalRedMug * (REDMUG);
				receiptRedMug += totalRedMug;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 3) //Yellow
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalYellowMug;
				total += totalYellowMug * (YELLOWMUG);
				receiptYellowMug += totalYellowMug;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;

			}

			else //User enters something other than 1, 2, or 3.
			{
				cout << "Invalid answer: please try again." << endl;
			}
			break;
		}
		case 2: //Bottles
		{

			char answer = ' '; //Colors
			cout << "You chose Fancy Water Bottles." << endl;
			cout << "1. Black" << endl;
			cout << "2. Red" << endl;
			cout << "3. Yellow" << endl;
			cin >> choice;

			if (choice == 1) //Black
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalBlackBottle;
				total += (totalBlackBottle * BLACKBOTTLE);
				receiptBlackBottle += totalBlackBottle;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 2) //Red
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalRedBottle;
				total += totalRedBottle * (REDBOTTLE);
				receiptRedBottle += totalRedBottle;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 3) //Yellow
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalYellowBottle;
				total += totalYellowBottle * (YELLOWBOTTLE);
				receiptYellowBottle += totalYellowBottle;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else //User enters something other than 1, 2, 3, or 4.
			{
				cout << "Invalid answer: please try again." << endl;
			}
			break;
		}
		case 3: //Cups
		{

			char answer = ' '; //Colors
			cout << "You chose Insulated Cups!" << endl;
			cout << "We have three different colors." << endl;
			cout << "1. Black" << endl;
			cout << "2. Red" << endl;
			cout << "3. Yellow" << endl;
			cin >> choice;

			if (choice == 1) //Black
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalBlackCup;
				total += totalBlackCup * (BLACKCUP);
				receiptBlackCup += totalBlackCup;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 2) //Red
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalRedCup;
				total += totalRedCup * (REDCUP);
				receiptRedCup += totalRedCup;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else if (choice == 3) //Yellow
			{
				cout << "How many would you like to buy: " << endl;
				cin >> totalYellowCup;
				total += totalYellowCup * (YELLOWCUP);
				receiptYellowCup += totalYellowCup;
				cout << fixed << showpoint << setprecision(2);
				cout << "Your total is currently: $"
					<< total << " with a tax of 7%." << endl;
			}

			else //User enters something other than 1, 2, or 3.
			{
				cout << "Invalid answer: please try again." << endl;
			}
			break;
		}
		default:
		{
			cout << "User exited or entered an improper answer. " << endl;
			break;
		}


		} //end of switch
		answer = ' ';
		cout << "Would you like to buy anything else? (y or n)" << endl;
		cin >> answer; //If user enters y they can buy more. If user enters any other character it goes to receipt.


	} while (answer == 'y' || answer == 'Y'); //end of do / while

	do //User can remove items from their cart.
	{
		cout << "Does your cart look okay? " << endl;

		/* Format as follows:
		Item Category:
		Item Color: Amount purchased
		*/

		cout << "Mugs: " << endl;
		cout << "\t Black: " << receiptBlackMug << endl;
		cout << "\t Red: " << receiptRedMug << endl;
		cout << "\t Yellow: " << receiptYellowMug << endl
			<< endl;
		cout << "Bottles: " << endl;
		cout << "\t Black: " << receiptBlackBottle << endl;
		cout << "\t Red: " << receiptRedBottle << endl;
		cout << "\t Yellow: " << receiptYellowBottle << endl
			<< endl;
		cout << "Cups: " << endl;
		cout << "\t Black: " << receiptBlackCup << endl;
		cout << "\t Red: " << receiptRedCup << endl;
		cout << "\t Yellow: " << receiptYellowCup << endl
			<< endl;

		cin >> answer2;

		if (answer2 == 'y' || answer2 == 'Y') //skips to the double check
		{
			cout << endl;
		}

		else if (answer2 == 'n' || answer2 == 'N') //lets user remove items.
		{
			cout << "What would you like to remove? " << endl;
			cout << "1. Mugs" << endl;
			cout << "2. Bottles " << endl;
			cout << "3. Cups" << endl;
			cin >> choice;

			switch (choice)
			{
			case 1: //Mugs
			{

				char answer = ' '; //Colors
				cout << "What color would you like to remove from your cart?" << endl;
				cout << "1. Black" << endl;
				cout << "2. Red" << endl;
				cout << "3. Yellow" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalBlackMug;
					if (receiptBlackMug - totalBlackMug >= 0)
					{
						total -= (totalBlackMug * BLACKMUG);
						receiptBlackMug -= totalBlackMug;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}
					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalRedMug;
					if (receiptRedMug - totalRedMug >= 0)
					{
						total -= totalRedMug * (REDMUG);
						receiptRedMug -= totalRedMug;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}
					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 3) //Yellow
				{
					if (receiptYellowMug - totalYellowMug >= 0)
					{
						cout << "How many would you like to remove: " << endl;
						cin >> totalYellowMug;
						total -= totalYellowMug * (YELLOWMUG);
						receiptYellowMug -= totalYellowMug;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}
					
					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}

				}

				else //User enters something other than 1, 2, or 3.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			}
			case 2: //Bottles
			{

				char answer = ' '; //Colors
				cout << "What color would you like to remove from your cart?" << endl;
				cout << "1. Black" << endl;
				cout << "2. Red" << endl;
				cout << "3. Yellow" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalBlackBottle;
					if (receiptBlackBottle - totalBlackBottle >= 0)
					{
						total -= (totalBlackBottle * BLACKBOTTLE);
						receiptBlackBottle -= totalBlackBottle;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}

					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalRedBottle;
					if (receiptRedBottle - totalRedBottle >= 0)
					{
						total -= totalRedBottle * (REDBOTTLE);
						receiptRedBottle -= totalRedBottle;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}
					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 3) //Yellow
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalYellowBottle;
					if (receiptYellowBottle - totalYellowBottle >= 0)
					{
						total -= totalYellowBottle * (YELLOWBOTTLE);
						receiptYellowBottle -= totalYellowBottle;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}
					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else //User enters something other than 1, 2, 3, or 4.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			}
			case 3: //Cups
			{

				char answer = ' '; //Colors
				cout << "What color would you like to remove from your cart?" << endl;
				cout << "1. Black" << endl;
				cout << "2. Red" << endl;
				cout << "3. Yellow" << endl;
				cin >> choice;

				if (choice == 1) //Black
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalBlackCup;
					if (receiptBlackCup - totalBlackCup >= 0)
					{
						total -= totalBlackCup * (BLACKCUP);
						receiptBlackCup -= totalBlackCup;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}

					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 2) //Red
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalRedCup;
					if (receiptRedCup - totalRedCup >= 0)
					{
						total -= totalRedCup * (REDCUP);
						receiptRedCup -= totalRedCup;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}

					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else if (choice == 3) //Yellow
				{
					cout << "How many would you like to remove: " << endl;
					cin >> totalYellowCup;
					if (receiptYellowCup - totalYellowCup >= 0)
					{
						total -= totalYellowCup * (YELLOWCUP);
						receiptYellowCup -= totalYellowCup;
						cout << fixed << showpoint << setprecision(2);
						cout << "Your total is now: $"
							<< total << " with a tax of 7%." << endl;
					}

					else //user attempts to remove more items than they have
					{
						cout << "You cannot remove more items than you have in your cart" << endl;
					}
				}

				else //User enters something other than 1, 2, or 3.
				{
					cout << "Invalid answer: please try again." << endl;
				}
				break;
			}
			default:
			{

				break;
			}


			} //end of switch
		}

		else
		{
			cout << "That was an improper answer. " << endl;
			cout << "Please respond with y/n" << endl;
		}

		answer2 = ' ';
		cout << "Is your cart okay now?" << endl;
		cin >> answer2;

	} while (answer2 == 'n' || answer2 == 'N');

	if (coupon == 0) //if user used a coupon for a specific item,
	{//they will be unable to use the coupon for 5% off total price.
		cout << "Do you have a coupon for 5% off your total price? " << endl;
		cin >> answer4;

		if (answer4 == 'y' || answer4 == 'Y') //user uses coupon
		{
			
			total = (total * 0.95);
			cout << endl;
		}

		else if (answer4 == 'n' || answer4 == 'N') // user doesn't use coupon
		{
			cout << "We have coupons in newspapers at the front of the store." << endl;
			cout << "Feel free to take one if you want one." << endl
				<< endl;
		}

		else // user enters an improper answer.
		{
			cout << "That wasn't a proper answer... " << endl
				<< endl;
		}
	}

	else // user used the coupon at the beginning of the program
	{
		cout << "You already used a coupon to buy something!" << endl
			<< "That means you can't use one to get a discount on your total price!" << endl;
	}
	

	/* Receipt format is as follows:
	Item Category
	Item Color: Amount purchased */
	cout << "Receipt: " << endl
		<< endl;
	cout << "Mugs: " << endl;
	cout << "\t Black: " << receiptBlackMug << endl;
	cout << "\t Red: " << receiptRedMug << endl;
	cout << "\t Yellow: " << receiptYellowMug << endl
		<< endl;
	cout << "Bottles: " << endl;
	cout << "\t Black: " << receiptBlackBottle << endl;
	cout << "\t Red: " << receiptRedBottle << endl;
	cout << "\t Yellow: " << receiptYellowBottle << endl
		<< endl;
	cout << "Cups: " << endl;
	cout << "\t Black: " << receiptBlackCup << endl;
	cout << "\t Red: " << receiptRedCup << endl;
	cout << "\t Yellow: " << receiptYellowCup << endl
		<< endl;

	cout << fixed << showpoint << setprecision(2);//sets receipt to 2 decimal points
	cout << "Subtotal:  $" << setfill('#') << setw(15) << total << endl; //whether they're used or not
	cout << "Sales Tax: $" << setfill('#') << setw(15) << total * (TAX) << endl;
	cout << "Total:     $" << setfill('#') << setw(15) << total * (TAX)+total << endl;


	cout << "Thank you for visiting J's Cup Shop!"
		<< " We hope you visit us again!" << endl;
	
	cin >> hold;
	return 0;
	//end of menu
}