//invalidYear Header file
#include <iostream>
#include <string>

using namespace std;

class invalidYear
{
	public:
		invalidYear()
		{
			message = "The year must be between 1900 and 2019.";
		}

		invalidYear(string str)
		{
			message = str;
		}

		string what()
		{
			return message;
		}

	private:
		string message;
};
