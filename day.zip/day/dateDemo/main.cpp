/*
	Name:			Joseph Summerlin
	Date:			12.3.2018
	Description:	Allows the user to enter their birth day info and will concatenate it and output it to the user.
*/
#include <iomanip>
#include <string>
#include "invalidDay.h"
#include "invalidMonth.h"
#include "invalidYear.h"

using namespace std;

//prototypes
int getDay(int mth, int yr);
int getMonth();
int getYear();

bool isLeapYear(int yr);

void printBirthDate(int day, int month, int year);

int main()
{
	//variables
	int day;
	int month = 0;
	int year;
	int hold;

	//Get the user's birthday info
	year = getYear(); //function call
	month = getMonth(); //function call
	day = getDay(month, year); //function call

	//Outputs the user's birthday
	cout << "Birth Day: ";
	printBirthDate(day, month, year); //function call

	cin >> hold;
	return 0;
	//end of main 
}

int getDay(int mth, int yr)
{
	bool done = false;
	int day = 0;

	do
	{
		try
		{
			//gets the user's birth day. If the day is less than 1 or greater than 28, 29, 30, or 31 (depending on the month)
			//then it will ask for the user to re-enter.
			cout << "Enter birth day: ";
			cin >> day;
			cout << endl;

			switch (mth)
			{
				//months with 31 days.
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					if (day < 1 || day > 31)
						throw invalidDay("Day must be between 1 and 31.");
					break;
					//months with 30 days.
				case 4:
				case 6:
				case 9:
				case 11:
					if (day < 1 || day > 30)
						throw invalidDay("Day must be between 1 and 30.");
					break;
					//months with 29 days
				case 2:
					if (isLeapYear(yr))
					{
						if (day < 1 || day > 29)
							throw invalidDay("Day must be between 1 and 29.");
					}
					else
						if (day < 1 || day > 28)
							throw invalidDay("Day must be between 1 and 28.");
			};

			done = true;
		}
		catch (invalidDay dayObj)
		{
			cout << dayObj.what() << endl;
		}

	} while (!done);

	return day;
}

int getMonth()
{
	bool done = false;
	int mth = 0;

	do
	{
		try //get user's birth month. If the month is less than 1 or greater than 12, it will ask the user to re-enter.
		{
			cout << "Enter month number: ";
			cin >> mth;
			cout << endl;

			if (mth < 1 || mth > 12)
				throw invalidMonth();

			done = true;
		}
		catch (invalidMonth mthObj)
		{
			cout << mthObj.what() << endl;
		}

	} while (!done); //end of do/while

	return mth; 
	//end of getDay
}

int getYear()
{
	bool done = false;
	int year = 0;

	do
	{
		try //gets user's birth year. If the year is less than 1900 or greater than 2018, it will ask the user to re-enter
		{
			cout << "Enter birth year: ";
			cin >> year;
			cout << endl;

			if (year < 1900 || year > 2018)
				throw year;

			done = true;
		}
		catch (int year)
		{
			cout << "Year must be between 1990 and 2018." << endl;
		}

	} while (!done);

	return year;
	//end of getYear
}

bool isLeapYear(int yr)
{
	//determines if a year is a leap year for February days
	if (((yr % 4 == 0) && (yr % 100 != 0)) || yr % 400 == 0)
		return true;
	else
		return false;
	//end of isLeapYear
}

void printBirthDate(int day, int month, int year)
{
	//changes month number to month name (i.e. 1 -> January)
	switch(month)
	{
		case 1:
			cout << "January";
			break;
		case 2:
			cout << "February";
			break;
		case 3:
			cout << "March";
			break;
		case 4:
			cout << "April";
			break;
		case 5:
			cout << "May";
			break;
		case 6:
			cout << "June";
			break;
		case 7:
			cout << "July";
			break;
		case 8:
			cout << "August";
			break;
		case 9:
			cout << "September";
			break;
		case 10:
			cout << "October";
			break;
		case 11:
			cout << "November";
			break;
		case 12:
			cout << "December";
			break;
	}

	cout << " " << day << ", " << year << endl;
	//end of printBirthDate
}